# BharatIntern-Internship-ML
A virtual internship program by Bharat Intern
### Task 1 - House Price Prediction :
Machine Learning model to predict house price using linear regression
### Task 2 - Iris Flowers Classification :
Predict the different species of flowers on the length of there petals and sepals

contains jupyter notebook with dataset
